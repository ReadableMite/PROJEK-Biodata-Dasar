#include<iostream>
using namespace std;
int main(){
    cout<<"Selanat Datang di Program Perulangan: For 'Roket'\nSilahkan Ikuti Program Berikut.\n"<<endl;
    for(int i=10;i>0;i--){
        cout<<i<<endl;
    }
    cout<<"MELUNCUR!";
    
    
    return 0;
}